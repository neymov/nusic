import asyncio, base64, json, os, shutil, sys, threading, time
import numpy as np
from datetime import datetime, timezone
import webview
try:
    from winrt.windows.media.control import (GlobalSystemMediaTransportControlsSessionManager as MM,
                                             GlobalSystemMediaTransportControlsSessionPlaybackStatus as PS)
    from winrt.windows.storage.streams import DataReader
    OK = True
except Exception as e:
    print('System media reading unavailable:', e)
    OK = False

try:
    import pyaudiowpatch as pa
    HAS_AUDIO = True
except Exception as e:
    print('Audio capture unavailable:', e)
    HAS_AUDIO = False

APPDATA = os.getenv('APPDATA') or '.'
DATA = os.path.join(APPDATA, 'nusic')
OLD = os.path.join(APPDATA, 'Islands')   # data from earlier builds
if not os.path.exists(DATA) and os.path.isdir(OLD):
    try:
        shutil.copytree(OLD, DATA)
    except Exception as e:
        print('migration:', e)
STATE = os.path.join(DATA, 'state.json')
PLAYING = False
LB = {'buf': np.zeros(1024, np.float32), 'at': 0.0}
BASE = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
LOOP = asyncio.new_event_loop()
mgr = None
sent_art = None
n_poll = 0

NAMES = [('308046b0af4a39cb', 'Firefox'), ('firefox', 'Firefox'), ('chrome', 'Chrome'), ('msedge', 'Edge'), ('edge', 'Edge'),
         ('spotify', 'Spotify'), ('opera', 'Opera'), ('brave', 'Brave'), ('vivaldi', 'Vivaldi'), ('yandex', 'Yandex'),
         ('zunemusic', 'Media Player'), ('vlc', 'VLC'), ('foobar', 'foobar2000'), ('telegram', 'Telegram')]

def app_name(i):
    l = (i or '').lower()
    for k, v in NAMES:
        if k in l:
            return v
    n = l.split('!')[-1].replace('.exe', '')
    return n.capitalize() or 'Windows'

async def manager():
    global mgr
    if mgr is None:
        mgr = await MM.request_async()
    return mgr

async def get_art(p):
    try:
        th = p.thumbnail
        if not th:
            return ''
        st = await th.open_read_async()
        n = st.size
        if not n:
            return ''
        r = DataReader(st)
        await r.load_async(n)
        b = bytearray(n)
        r.read_bytes(b)
        return 'data:%s;base64,%s' % (st.content_type or 'image/jpeg', base64.b64encode(bytes(b)).decode())
    except Exception:
        return ''

async def snap():
    global sent_art
    s = (await manager()).get_current_session()
    if not s:
        return None
    p = await s.try_get_media_properties_async()
    if not (p.title or p.artist):
        return None
    global PLAYING
    playing = PLAYING = s.get_playback_info().playback_status == PS.PLAYING
    tl = s.get_timeline_properties()
    pos = tl.position.total_seconds()
    dur = (tl.end_time - tl.start_time).total_seconds()
    if playing:
        try:
            pos += (datetime.now(timezone.utc) - tl.last_updated_time).total_seconds()
        except Exception:
            pass
    pos = max(0, pos)
    if dur > 0:
        pos = min(pos, dur)
    else:
        dur = 0
    art = await get_art(p)
    global n_poll
    n_poll += 1
    a = None if art == sent_art and n_poll % 15 else art   # send artwork only on change
    if a is not None:
        sent_art = art
    return {'title': p.title or '', 'artist': p.artist or '', 'art': a, 'playing': playing,
            'cur': pos, 'dur': dur, 'site': app_name(s.source_app_user_model_id)}

async def poll(win):
    while True:
        try:
            d = await snap()
            if d:
                win.evaluate_js("window.postMessage({islandsBridge:1,type:'sc',data:%s},'*')" % json.dumps(d))
        except Exception as e:
            print(e)
        await asyncio.sleep(1)

async def do(c):
    s = (await manager()).get_current_session()
    if s:
        await {'play': s.try_toggle_play_pause_async, 'next': s.try_skip_next_async, 'prev': s.try_skip_previous_async}[c]()

def spectrum(b, prev, w):
    x = np.abs(np.fft.rfft(b * w))[:512] / 1024
    prev = .8 * prev + .2 * x
    f = np.clip((20 * np.log10(prev + 1e-9) + 100) / 70 * 255, 0, 255).astype(np.uint8)
    t = np.clip(128 + b[::8] * 160, 0, 255).astype(np.uint8)
    return prev, base64.b64encode(f.tobytes()).decode(), base64.b64encode(t.tobytes()).decode()

def out_name():
    q = pa.PyAudio()
    try:
        return q.get_device_info_by_index(q.get_host_api_info_by_type(pa.paWASAPI)['defaultOutputDevice'])['name']
    finally:
        q.terminate()

def capture():
    while True:
        try:
            p = pa.PyAudio()
            d = p.get_device_info_by_index(p.get_host_api_info_by_type(pa.paWASAPI)['defaultOutputDevice'])
            base = d['name']
            if not d.get('isLoopbackDevice'):
                for l in p.get_loopback_device_info_generator():
                    if base in l['name']:
                        d = l
                        break
            ch = int(d['maxInputChannels']) or 2
            def cb(data, frames, info, status):
                m = (np.frombuffer(data, np.int16).astype(np.float32) / 32768).reshape(-1, ch).mean(1)
                LB['buf'] = np.concatenate([LB['buf'], m])[-1024:]
                LB['at'] = time.time()
                return (None, pa.paContinue)
            st = p.open(format=pa.paInt16, channels=ch, rate=int(d['defaultSampleRate']), frames_per_buffer=512,
                        input=True, input_device_index=d['index'], stream_callback=cb)
            while st.is_active():
                time.sleep(3)
                if out_name() != base:
                    break
            st.stop_stream(); st.close(); p.terminate()
        except Exception as e:
            print('loopback:', e)
            time.sleep(3)

def send_spectrum(win):
    w = np.blackman(1024).astype(np.float32)
    prev = np.zeros(512, np.float32)
    while True:
        time.sleep(.04)
        if not PLAYING:
            continue
        b = LB['buf'] if time.time() - LB['at'] < .25 else np.zeros(1024, np.float32)
        prev, f, t = spectrum(b, prev, w)
        try:
            win.evaluate_js("window.postMessage({islandsBridge:1,type:'fft',f:'%s',t:'%s'},'*')" % (f, t))
        except Exception:
            pass

def restore(win):
    try:
        t = open(STATE, encoding='utf-8').read()
        cur = win.evaluate_js("(()=>{try{return (JSON.parse(localStorage.getItem('isl4')||'null')||{}).ts||0}catch(e){return 0}})()") or 0
        if json.loads(t).get('ts', 0) > cur:
            win.evaluate_js("localStorage.setItem('isl4',%s);location.reload()" % json.dumps(t))
            time.sleep(2)
    except FileNotFoundError:
        pass
    except Exception as e:
        print('restore:', e)

class Api:
    def fullscreen(self):
        win.toggle_fullscreen()

    def save(self, t):
        try:
            os.makedirs(os.path.dirname(STATE), exist_ok=True)
            tmp = STATE + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                f.write(t)
            os.replace(tmp, STATE)
        except Exception as e:
            print('save:', e)

    def cmd(self, c):
        if OK and c in ('play', 'next', 'prev'):
            asyncio.run_coroutine_threadsafe(do(c), LOOP)

def boot(win):
    win.events.loaded.wait()
    restore(win)
    if HAS_AUDIO:
        threading.Thread(target=capture, daemon=True).start()
        threading.Thread(target=send_spectrum, args=(win,), daemon=True).start()
    if OK:
        threading.Thread(target=LOOP.run_forever, daemon=True).start()
        asyncio.run_coroutine_threadsafe(poll(win), LOOP)

win = webview.create_window('nusic', os.path.join(BASE, 'nusic.html'), js_api=Api(),
                            width=1280, height=800, background_color='#000000')
webview.start(boot, win, private_mode=False, storage_path=DATA)
